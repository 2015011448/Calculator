package com.mingrisoft.calculator;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends Activity {
    Button one,two,three,four,five,six,seven,eight,nine,zero,circle,equal;
    Button add,jian,mul,chu;
    //Button zuo,you;
    Button back,clear;
    Button button,button1,button2;
    EditText input;
    boolean clr_flag;
    private MyOnClickListener listener=new MyOnClickListener();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        one=(Button)findViewById(R.id.one);
        two=(Button)findViewById(R.id.two);
        three=(Button)findViewById(R.id.three);
        four=(Button)findViewById(R.id.four);
        five=(Button)findViewById(R.id.five);
        six=(Button)findViewById(R.id.six);
        seven=(Button)findViewById(R.id.seven);
        eight=(Button)findViewById(R.id.eight);
        nine=(Button)findViewById(R.id.nine);
        zero=(Button)findViewById(R.id.zero);
        circle=(Button)findViewById(R.id.circle);
        equal=(Button)findViewById(R.id.equal);
        add=(Button)findViewById(R.id.add);
        jian=(Button)findViewById(R.id.jian);
        mul=(Button)findViewById(R.id.mul);
        chu=(Button)findViewById(R.id.chu);
        //zuo=(Button)findViewById(R.id.zuo);
        //you=(Button)findViewById(R.id.you);
        back=(Button)findViewById(R.id.back);
        clear=(Button)findViewById(R.id.clear);
        button=(Button)findViewById(R.id.function);
        button1=(Button)findViewById(R.id.decimal);
        button2=(Button)findViewById(R.id.unit_conversion);
        input=(EditText)findViewById(R.id.input);
        one.setOnClickListener(listener);
        two.setOnClickListener(listener);
        three.setOnClickListener(listener);
        four.setOnClickListener(listener);
        five.setOnClickListener(listener);
        six.setOnClickListener(listener);
        seven.setOnClickListener(listener);
        eight.setOnClickListener(listener);
        nine.setOnClickListener(listener);
        zero.setOnClickListener(listener);
        circle.setOnClickListener(listener);
        equal.setOnClickListener(listener);
       // zuo.setOnClickListener(listener);
        //you.setOnClickListener(listener);
        add.setOnClickListener(listener);
        jian.setOnClickListener(listener);
        mul.setOnClickListener(listener);
        chu.setOnClickListener(listener);
        back.setOnClickListener(listener);
        clear.setOnClickListener(listener);
        button.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent=new Intent(MainActivity.this,FunctionCalculation.class);
                startActivity(intent);
            }
        });
        button1.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent=new Intent(MainActivity.this,BinaryConversion.class);
                startActivity(intent);
            }
        });
        button2.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent=new Intent(MainActivity.this,UnitConversion.class);
                startActivity(intent);
            }
        });
    }
    class MyOnClickListener implements View.OnClickListener{
        public void onClick(View v){

            String str=input.getText().toString();
            switch (v.getId()){
                case R.id.zero:
                case R.id.one:
                case R.id.two:
                case R.id.three:
                case R.id.four:
                case R.id.five:
                case R.id.six:
                case R.id.seven:
                case R.id.eight:
                case R.id.nine:
                case R.id.circle:
                    if (clr_flag){
                        clr_flag=false;
                        str="";
                        input.setText("");//让此时的输入框内容为空
                    }
                    input.setText(str+((Button)v).getText());
                    break;
                case R.id.add:
                case R.id.jian:
                case R.id.mul:
                case R.id.chu:
                    if (clr_flag){
                        clr_flag=false;
                        str="";
                        input.setText("");//让此时的输入框内容为空
                    }
                    if (str.contains("+")||str.contains("-")||str.contains("*")||str.contains("/")){
                        str=str.substring(0,str.indexOf(" "));
                    }
                    input.setText(str+" "+((Button)v).getText()+" ");
                    break;
                case R.id.clear:
                    if (clr_flag) {
                        clr_flag = false;
                    }
                    str="";
                    input.setText("");
                    break;
                case R.id.back:
                    if (clr_flag){
                        clr_flag=false;
                        str="";
                        input.setText("");//让此时的输入框内容为空
                    }
                    else if(str!=null&&!str.equals("")){
                        input.setText(str.substring(0,str.length()-1));
                    }
                    break;
                case R.id.equal:
                    getResult();
                    break;
            }
        }
        public void getResult(){
            String exp=input.getText().toString();
            if(exp==null||exp.equals("")) return ; //因为没有运算符所以不用运算
            if (!exp.contains(" ")){
                return;
            }
            if(clr_flag){
                clr_flag=false;
                return;
            }
            clr_flag=true;
            String s1=exp.substring(0,exp.indexOf(" "));//获取运算符前面的字符串
            String op=exp.substring(exp.indexOf(" ")+1,exp.indexOf(" ")+2);//获取运算符
            String s2=exp.substring(exp.indexOf(" ")+3);//获取运算符后面的字符串
            double cnt=0;
            if(!s1.equals("")&&!s2.equals("")){
                double d1=Double.parseDouble(s1);
                double d2=Double.parseDouble(s2);
                if (op.equals("+")){
                    cnt=d1+d2;
                }
                if (op.equals("-")){
                    cnt=d1-d2;
                }
                if (op.equals("*")){
                    cnt=d1*d2;
                }
                if (op.equals("/")){
                    if (d2==0){
                        cnt=0;
                    }else{
                        cnt=d1/d2;
                    }

                }
                if(!s1.contains(".")&&!s2.contains(".")&&!op.equals("/")){
                    int res = (int) cnt;
                    input.setText(res+"");
                }
                else {
                    input.setText(cnt+"");
                }
            }
            else if(!s1.equals("")&&s2.equals("")){
                double d1=Double.parseDouble(s1);
                if(op.equals("+")){
                    cnt=d1;
                }
                if(op.equals("-")){
                    cnt=d1;
                }
                if(op.equals("*")){
                    cnt=0;
                }
                if(op.equals("/")){
                    cnt=0;
                }
                if(!s1.contains(".")){
                    int res = (int) cnt;
                    input.setText(res+"");
                }
                else {
                    input.setText(cnt+"");
                }
            }
            else if(s1.equals("")&&!s2.equals("")){
                double d2=Double.parseDouble(s2);
                if(op.equals("+")){
                    cnt=d2;
                }
                if(op.equals("-")){
                    cnt=0-d2;
                }
                if(op.equals("*")){
                    cnt=0;
                }
                if(op.equals("/")){
                    cnt=0;
                }
                if(!s2.contains(".")){
                    int res = (int) cnt;
                    input.setText(res+"");
                }
                else {
                    input.setText(cnt+"");
                }
            }
            else {
                input.setText("");
            }
        }
    }
}
