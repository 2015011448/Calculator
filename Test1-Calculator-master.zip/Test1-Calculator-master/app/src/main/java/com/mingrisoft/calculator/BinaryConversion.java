package com.mingrisoft.calculator;

import android.app.Activity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class BinaryConversion extends Activity {
    Button yi,two,three,four,five,six,seven,eight,nine,zero;
    Button a,b,c,d,e,f;
    Button back,clear;
    Button binary_system,ten,octal,hexadecimal;
    EditText input;
    boolean clr_flag;
   private MyOnClickListener listener=new MyOnClickListener();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_binary_conversion);
        yi=(Button)findViewById(R.id.pne);
        two=(Button)findViewById(R.id.two);
        three=(Button)findViewById(R.id.three);
        four=(Button)findViewById(R.id.four);
        five=(Button)findViewById(R.id.five);
        six=(Button)findViewById(R.id.six);
        seven=(Button)findViewById(R.id.seven);
        eight=(Button)findViewById(R.id.eight);
        nine=(Button)findViewById(R.id.nine);
        zero=(Button)findViewById(R.id.zero);
        a=(Button)findViewById(R.id.a);
        b=(Button)findViewById(R.id.b);
        c=(Button)findViewById(R.id.c);
        d=(Button)findViewById(R.id.d);
        e=(Button)findViewById(R.id.e);
        f=(Button)findViewById(R.id.f);
        back=(Button)findViewById(R.id.delete) ;
        clear=(Button)findViewById(R.id.deleteall);
        binary_system=(Button)findViewById(R.id.binary_system);
        ten=(Button)findViewById(R.id.ten);
        octal=(Button)findViewById(R.id.octal);
        hexadecimal=(Button)findViewById(R.id.hexadecimal);
        input=(EditText) findViewById(R.id.input);
        yi.setOnClickListener(listener);
        two.setOnClickListener(listener);
        three.setOnClickListener(listener);
        four.setOnClickListener(listener);
        five.setOnClickListener(listener);
        six.setOnClickListener(listener);
        seven.setOnClickListener(listener);
        eight.setOnClickListener(listener);
        nine.setOnClickListener(listener);
        zero.setOnClickListener(listener);
        a.setOnClickListener(listener);
        b.setOnClickListener(listener);
        c.setOnClickListener(listener);
        d.setOnClickListener(listener);
        e.setOnClickListener(listener);
        f.setOnClickListener(listener);
        back.setOnClickListener(listener);
        clear.setOnClickListener(listener);
        hexadecimal.setOnClickListener(listener);
        ten.setOnClickListener(listener);
        octal.setOnClickListener(listener);
        binary_system.setOnClickListener(listener);
    }
    class MyOnClickListener implements View.OnClickListener{
        public void onClick(View v){
            String str=input.getText().toString();
            switch (v.getId()){
                case R.id.pne:
                case R.id.two:
                case R.id.three:
                case R.id.four:
                case R.id.five:
                case R.id.six:
                case R.id.seven:
                case R.id.eight:
                case R.id.nine:
                case R.id.zero:
                case R.id.a:
                case R.id.b:
                case R.id.c:
                case R.id.d:
                case R.id.e:
                case R.id.f:
                    if (clr_flag){
                    clr_flag=false;
                    str="";
                    input.setText("");
                }
                input.setText(str+((Button)v).getText());
                break;
                case R.id.delete:
                    if (clr_flag){
                        clr_flag=false;
                        str="";
                        input.setText("");//让此时的输入框内容为空
                    }
                    else if(str!=null&&!str.equals("")){
                        input.setText(str.substring(0,str.length()-1));
                    }
                    break;
                case R.id.deleteall:
                    if (clr_flag) {
                        clr_flag = false;
                    }
                    str="";
                    input.setText("");
                    break;
                case R.id.binary_system:
                    getBinary();
                    break;
                case R.id.ten:
                    getTen();
                    break;
                case R.id.octal:
                    getOctal();
                    break;
                case R.id.hexadecimal:
                    getHexadecimal();
                    break;
            }
        }
        public void getBinary(){
            String exp=input.getText().toString();
            long l=Long.parseLong(exp);
            String m=Long.toBinaryString(l);
            input.setText(m);
        }
        public void getTen(){
            String exp=input.getText().toString();
            int l=Integer.parseInt(exp);
            String m=Long.toString(l);
            input.setText(m);
        }
        public void getOctal(){
            String exp=input.getText().toString();
            long l=Long.parseLong(exp);
            String m=Long.toOctalString(l);
            input.setText(m);
        }
        public void getHexadecimal(){
            String exp=input.getText().toString();
            long l=Long.parseLong(exp);
            String m=Long.toHexString(l);
            input.setText(m);
        }
    }
}
