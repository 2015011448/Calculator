package com.mingrisoft.calculator;

import android.app.Activity;
import android.content.Intent;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class UnitConversion extends Activity {
    private String[] data={"1 千米（km） 等于                   1千米","1 千米（km） 等于                   1000米","1 千米（km） 等于                   10000分米",
            "1 千米（km） 等于                   100000厘米","1 千米（km） 等于                   1000000毫米",
            "1 千米（km） 等于                   1000000000微米","1 千米（km） 等于                    39370.0787英寸",
            "1 千米（km） 等于                    3280.83989码","1 千米（km） 等于                    0.6213712英里",
            "1 千米（km） 等于                    0.5399568海里","1 千米（km） 等于                    2里",
            "1 千米（km） 等于                    300丈","1 千米（km） 等于                    3000尺",
            "1 千米（km） 等于                    30000寸","1 千米（km） 等于                    300000分",
            "1 千米（km） 等于                    3000000厘","1 千米（km） 等于                    3000000毫"

    };
    Button btn1,btn2,btn3,btn4,btn5;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_unit_conversion);
        ArrayAdapter<String> adapter=new ArrayAdapter<String>(UnitConversion.this,android.R.layout.simple_list_item_1,data);
        ListView listView=(ListView)findViewById(R.id.list_view);
        listView.setAdapter(adapter);
        btn1=(Button)findViewById(R.id.length);
        btn2=(Button)findViewById(R.id.area);
        btn3=(Button)findViewById(R.id.tiji);
        btn4=(Button)findViewById(R.id.object);
        btn5=(Button)findViewById(R.id.wendu);
        btn1.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent=new Intent(UnitConversion.this,UnitConversion.class);
                startActivity(intent);
            }
        });
        btn2.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent=new Intent(UnitConversion.this,Area.class);
                startActivity(intent);
            }
        });
        btn3.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent=new Intent(UnitConversion.this,Tiji.class);
                startActivity(intent);
            }
        });
        btn4.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent=new Intent(UnitConversion.this,Object.class);
                startActivity(intent);
            }
        });
        btn5.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent=new Intent(UnitConversion.this,Wendu.class);
                startActivity(intent);
            }
        });
    }
}
