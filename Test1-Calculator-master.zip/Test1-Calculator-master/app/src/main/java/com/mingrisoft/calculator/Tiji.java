package com.mingrisoft.calculator;

import android.app.Activity;
import android.content.Intent;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

public class Tiji extends Activity {
    Button btn1,btn2,btn3,btn4,btn5;
    private String[] data={"1 立方米       等于                   1立方米","1 立方米       等于                   1000立方分米",
            "1 立方米       等于                   1000000立方厘米","1 立方米       等于                   1000升",
            "1 立方米       等于                   10000分升","1 立方米       等于                   10公石",
            "1 立方米       等于                   8.107E-4亩英尺","1 立方米       等于                   219.9691英制加仑"
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tiji);
        ArrayAdapter<String> adapter=new ArrayAdapter<String>(Tiji.this,android.R.layout.simple_list_item_1,data);
        ListView listView=(ListView)findViewById(R.id.list_view2);
        listView.setAdapter(adapter);
        btn1=(Button)findViewById(R.id.length);
        btn2=(Button)findViewById(R.id.area);
        btn3=(Button)findViewById(R.id.tiji);
        btn4=(Button)findViewById(R.id.object);
        btn5=(Button)findViewById(R.id.wendu);
        btn1.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent=new Intent(Tiji.this,UnitConversion.class);
                startActivity(intent);
            }
        });
        btn2.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent=new Intent(Tiji.this,Area.class);
                startActivity(intent);
            }
        });
        btn3.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent=new Intent(Tiji.this,Tiji.class);
                startActivity(intent);
            }
        });
        btn4.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent=new Intent(Tiji.this,Object.class);
                startActivity(intent);
            }
        });
        btn5.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent=new Intent(Tiji.this,Wendu.class);
                startActivity(intent);
            }
        });
    }
}

