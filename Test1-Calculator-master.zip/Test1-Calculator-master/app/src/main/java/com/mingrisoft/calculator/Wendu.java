package com.mingrisoft.calculator;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

public class Wendu extends AppCompatActivity {
    private String[] data={"1 摄氏度（℃）      等于       1摄氏度（℃）","1 摄氏度（℃）      等于       33.8华氏度（℉）",
            "1 摄氏度（℃）      等于       0.8列氏度","1 摄氏度（℃）      等于       274.15开氏度（K）",
            "1 摄氏度（℃）      等于       493.47兰氏度（℃）"
    };
    Button btn1,btn2,btn3,btn4,btn5;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wendu);
        ArrayAdapter<String> adapter=new ArrayAdapter<String>(Wendu.this,android.R.layout.simple_list_item_1,data);
        ListView listView=(ListView)findViewById(R.id.list_view1);
        listView.setAdapter(adapter);
        btn1=(Button)findViewById(R.id.length);
        btn2=(Button)findViewById(R.id.area);
        btn3=(Button)findViewById(R.id.tiji);
        btn4=(Button)findViewById(R.id.object);
        btn5=(Button)findViewById(R.id.wendu);
        btn1.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent=new Intent(Wendu.this,UnitConversion.class);
                startActivity(intent);
            }
        });
        btn2.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent=new Intent(Wendu.this,Area.class);
                startActivity(intent);
            }
        });
        btn3.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent=new Intent(Wendu.this,Tiji.class);
                startActivity(intent);
            }
        });
        btn4.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent=new Intent(Wendu.this,Object.class);
                startActivity(intent);
            }
        });
        btn5.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent=new Intent(Wendu.this,Wendu.class);
                startActivity(intent);
            }
        });
    }
}
