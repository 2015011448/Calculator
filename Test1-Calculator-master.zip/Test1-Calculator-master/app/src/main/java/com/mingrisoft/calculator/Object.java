package com.mingrisoft.calculator;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

public class Object extends AppCompatActivity {
    Button btn1,btn2,btn3,btn4,btn5;
    private String[] data={"1 千克       等于                   1千克","1 千克       等于                   1000克",
            "1 千克       等于                   0.001吨","1 千克       等于                   5000克拉",
            "1 千克       等于                   2.2046226磅","1 千克       等于                   0.02担",
            "1 千克       等于                   2斤","1 千克       等于                   20量",
            "1 千克       等于                   0.02钱"
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_object);
        ArrayAdapter<String> adapter=new ArrayAdapter<String>(Object.this,android.R.layout.simple_list_item_1,data);
        ListView listView=(ListView)findViewById(R.id.list_view4);
        listView.setAdapter(adapter);
        btn1=(Button)findViewById(R.id.length);
        btn2=(Button)findViewById(R.id.area);
        btn3=(Button)findViewById(R.id.tiji);
        btn4=(Button)findViewById(R.id.object);
        btn5=(Button)findViewById(R.id.wendu);
        btn1.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent=new Intent(Object.this,UnitConversion.class);
                startActivity(intent);
            }
        });
        btn2.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent=new Intent(Object.this,Area.class);
                startActivity(intent);
            }
        });
        btn3.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent=new Intent(Object.this,Tiji.class);
                startActivity(intent);
            }
        });
        btn4.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent=new Intent(Object.this,Object.class);
                startActivity(intent);
            }
        });
        btn5.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent=new Intent(Object.this,Wendu.class);
                startActivity(intent);
            }
        });
    }
}

