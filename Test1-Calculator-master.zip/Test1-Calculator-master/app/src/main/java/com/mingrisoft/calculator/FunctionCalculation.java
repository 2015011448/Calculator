package com.mingrisoft.calculator;

import android.app.Activity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class FunctionCalculation extends Activity {
    Button one,two,three,four,five,six,seven,eight,nine,zero,circle,equal;
    Button add,jian,mul,chu;
    Button back,clear;
    EditText input;
    Button tan,sin,cos,log,ln,sqrt;
    boolean clr_flag;
    private MyOnClickListener listener=new MyOnClickListener();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_function_calculation);
        one=(Button)findViewById(R.id.one);
        two=(Button)findViewById(R.id.two);
        three=(Button)findViewById(R.id.three);
        four=(Button)findViewById(R.id.four);
        five=(Button)findViewById(R.id.five);
        six=(Button)findViewById(R.id.six);
        seven=(Button)findViewById(R.id.seven);
        eight=(Button)findViewById(R.id.eight);
        nine=(Button)findViewById(R.id.nine);
        zero=(Button)findViewById(R.id.zero);
        input=(EditText)findViewById(R.id.input);
        circle=(Button)findViewById(R.id.circle);
        equal=(Button)findViewById(R.id.equal);
        add=(Button)findViewById(R.id.add);
        jian=(Button)findViewById(R.id.jian);
        mul=(Button)findViewById(R.id.mul);
        chu=(Button)findViewById(R.id.chu);
        back=(Button)findViewById(R.id.back);
        clear=(Button)findViewById(R.id.clear);
        tan=(Button)findViewById(R.id.tan);
        sin=(Button)findViewById(R.id.sin);
        cos=(Button)findViewById(R.id.cos);
        ln=(Button)findViewById(R.id.ln);
        log=(Button)findViewById(R.id.log);
        sqrt=(Button)findViewById(R.id.root_number);
        one.setOnClickListener(listener);
        two.setOnClickListener(listener);
        three.setOnClickListener(listener);
        four.setOnClickListener(listener);
        five.setOnClickListener(listener);
        six.setOnClickListener(listener);
        seven.setOnClickListener(listener);
        eight.setOnClickListener(listener);
        nine.setOnClickListener(listener);
        zero.setOnClickListener(listener);
        circle.setOnClickListener(listener);
        equal.setOnClickListener(listener);
        add.setOnClickListener(listener);
        jian.setOnClickListener(listener);
        mul.setOnClickListener(listener);
        chu.setOnClickListener(listener);
        back.setOnClickListener(listener);
        clear.setOnClickListener(listener);
        tan.setOnClickListener(listener);
        sin.setOnClickListener(listener);
        cos.setOnClickListener(listener);
        ln.setOnClickListener(listener);
        log.setOnClickListener(listener);
        sqrt.setOnClickListener(listener);
    }
    class MyOnClickListener implements View.OnClickListener{
        public void onClick(View v){

            String str=input.getText().toString();
            switch (v.getId()){
                case R.id.zero:
                case R.id.one:
                case R.id.two:
                case R.id.three:
                case R.id.four:
                case R.id.five:
                case R.id.six:
                case R.id.seven:
                case R.id.eight:
                case R.id.nine:
                case R.id.circle:
                    if (clr_flag){
                        clr_flag=false;
                        str="";
                        input.setText("");//让此时的输入框内容为空
                    }
                    input.setText(str+((Button)v).getText());
                    break;
                case R.id.add:
                case R.id.jian:
                case R.id.mul:
                case R.id.chu:
                    if (clr_flag){
                        clr_flag=false;
                        str="";
                        input.setText("");//让此时的输入框内容为空
                    }
                    if (str.contains("+")||str.contains("-")||str.contains("*")||str.contains("/")){
                        str=str.substring(0,str.indexOf(" "));
                    }
                    input.setText(str+" "+((Button)v).getText()+" ");
                    break;
                case R.id.clear:
                    if (clr_flag) {
                        clr_flag = false;
                    }
                    str="";
                    input.setText("");
                    break;
                case R.id.back:
                    if (clr_flag){
                        clr_flag=false;
                        str="";
                        input.setText("");//让此时的输入框内容为空
                    }
                    else if(str!=null&&!str.equals("")){
                        input.setText(str.substring(0,str.length()-1));
                    }
                    break;
                case R.id.equal:
                    getResult();
                    break;
                case R.id.tan:
                case R.id.sin:
                case R.id.cos:
                case R.id.ln:
                case R.id.log:
                case R.id.root_number:
                    if (clr_flag){
                        clr_flag=false;
                        str="";
                        input.setText("");//让此时的输入框内容为空
                    }
                    input.setText(str+" "+((Button)v).getText()+" ");
                    break;
            }
        }
       public void getResult(){
            String exp=input.getText().toString();

            if(exp==null||exp.equals("")) return ; //因为没有运算符所以不用运算
            if (!exp.contains(" ")){
                return;
            }
            if(clr_flag){
                clr_flag=false;
                return;
            }
            clr_flag=true;
           if (exp.contains("tan")){
               String t2=exp.substring(exp.indexOf(" ")+5);
               double b=Double.parseDouble(t2);
               double c=Math.toRadians(b);
               double d=Math.tan(c);
               String s=Double.toString(d);
               input.setText(s);
           }
           if (exp.contains("sin")){
               String t2=exp.substring(exp.indexOf(" ")+5);
               double b=Double.parseDouble(t2);
               double c=Math.toRadians(b);
               double d=Math.sin(c);
               String s=Double.toString(d);
               input.setText(s);
           }
           if (exp.contains("cos")){
               String t2=exp.substring(exp.indexOf(" ")+5);
               double b=Double.parseDouble(t2);
               double c=Math.toRadians(b);
               double d=Math.cos(c);
               String s=Double.toString(d);
               input.setText(s);
           }
//           log((double)N)/log((double)x)
           if (exp.contains("ln")){
               String t1=exp.substring(exp.indexOf(" ")+4,exp.indexOf(" ")+5);
               String t2=exp.substring(exp.indexOf(" ")+5);
               double d1=Double.parseDouble(t1);
               double d2=Double.parseDouble(t2);
               double d3=Math.log(d2)/Math.log(d1);
               String t3=Double.toString(d3);
               input.setText(t3);
           }
           if (exp.contains("log")){
               String t1=exp.substring(exp.indexOf(" ")+5,exp.indexOf(" ")+6);
               String t2=exp.substring(exp.indexOf(" ")+6);
               double d1=Double.parseDouble(t1);
               double d2=Double.parseDouble(t2);
               double d3=Math.log(d2)/Math.log(d1);
               String t3=Double.toString(d3);
               input.setText(t3);
           }
           if (exp.contains("√")){
               String t1=exp.substring(exp.indexOf(" ")+3);
               double d1=Double.parseDouble(t1);
               double d2=Math.sqrt(d1);
               String t2=Double.toString(d2);
               input.setText(t2);
           }
        }
   }
}
